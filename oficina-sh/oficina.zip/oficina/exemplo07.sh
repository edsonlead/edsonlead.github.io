#!/bin/bash

HELP="

Uso: $0 [-h]

-h		Mostra informação de ajuda

"

if test "$1" = "-h"
then
	echo "$HELP"
	exit 0
fi
