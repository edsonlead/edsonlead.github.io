#!/bin/bash

#Informações do sistema
#Interação com usuário

echo "Deseja atualizar o sistema? [s / n]"
read RESPOSTA

if test "$RESPOSTA" = "n" -o "$RESPOSTA" = "N"
then
	exit
elif test "$RESPOSTA" = "s" -o "$RESPOSTA" = "S"
then
	sudo dnf update -y
else
	echo "Responda apenas 's/S' ou 'n/N' "
fi
