#!/bin/bash


if test "$1" = "-v"
then
	echo "$0 versão 1.0"
fi
