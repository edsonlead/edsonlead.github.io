#!/bin/bash

echo "Verificar existência do arquivo: "
read ARQUIVO

if [ -e $ARQUIVO ]
then
	echo -e "\033[32m $ARQUIVO existe \033[m"
else
	echo -e "\033[31m $ARQUIVO NÃO existe \033[m"
fi

