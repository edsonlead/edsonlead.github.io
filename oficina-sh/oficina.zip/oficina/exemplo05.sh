#!/bin/bash

echo "O nome deste script é: $0"
echo
echo "Recebidos $# argumentos: $*"
echo
echo "O primeiro argumento recebido foi: $1"
echo
echo "O segundo argumento recebido foi: $2"
