#!/bin/bash

df > out &

dialog	\
	--title "Monitorando uso de disco"	\
	--tailbox out	\
	60 100

clear
