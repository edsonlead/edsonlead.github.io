#!/bin/bash

dialog	\
	--title "Dialog"	\
	--msgbox "Olá, estou na Oficina de Shell Script"	\
	6 40
