#!/bin/bash

HELP="

Uso: $0 programa

"

if test “$1” = “-v”
then
    echo “Versão do script: 1.0”

elif test “$1” = “-h”
then
    echo “$HELP”
    exit 0
else
    sudo dnf install "$1"
fi
