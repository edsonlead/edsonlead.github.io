#!/bin/bash
dialog                                       \
    --title "Instalação de Programa"                          \
    --menu "Escolha um programa para instalação: "  \
    0 0 0                                     \
    SimpleHTTPServer	"Servidor web"           \
    NoSQL	"Banco de dados"               \
    Python	"Linguagem de programação"
clear
