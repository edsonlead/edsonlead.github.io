#!/bin/bash

echo -n "Digite o nome do arquivo: "
read ARQUIVO

test -e "$ARQUIVO" && echo "$ARQUIVO existe"

test -d "$ARQUIVO" && echo "$ARQUIVO é um diretório"

test -f "$ARQUIVO" && echo "$ARQUIVO é um arquivo"

test -f "$ARQUIVO" -o -d "$ARQUIVO" || echo "Arquivo não encontrado!"

echo
