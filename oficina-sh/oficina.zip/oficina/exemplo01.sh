#!/bin/bash

#Informações do sistema

echo "Data e Horário:"
date
echo
echo "Uso do disco:"
df
echo
echo "Nome do usuário:"
echo $USER
