#!/bin/bash

#Informações do sistema
#Interação com usuário

echo "Deseja buscar informações do sistema? [s / n]"
read RESPOSTA

test "$RESPOSTA" = "n" && exit

echo "Data e Horário:"
date
echo
echo "Uso do disco:"
df
echo
echo "Nome do usuário:"
echo $USER
