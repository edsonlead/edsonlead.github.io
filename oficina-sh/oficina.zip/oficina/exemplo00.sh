#!/bin/bash

ifconfig wlp9s0 up
iwconfig wlp9s0 essid Linux
dhclient wlp9s0
